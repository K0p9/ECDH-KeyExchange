﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Lab03.Bai4.Server
{
    public partial class Server : Form
    {
        TcpListener server;
        List<TcpClient> clients = new List<TcpClient>();
        List<string> connectedClients = new List<string>();
        public Server()
        {
            InitializeComponent();
            richTextBox1.ReadOnly = true;
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(700, 0);
        }

        private void Server_Load(object sender, EventArgs e)
        {
            server = new TcpListener(IPAddress.Any, 9999);
            server.Start();
            richTextBox1.AppendText("Server started.\n");

            Thread listenThread = new Thread(Listen);
            listenThread.Start();
        }

        private void Listen()
        {
            while (true)
            {
                TcpClient client = server.AcceptTcpClient();
                clients.Add(client);
                connectedClients.Add(client.Client.RemoteEndPoint.ToString());
                UpdateConnectedClients();
                Thread clientThread = new Thread(() => HandleClient(client));
                clientThread.Start();
            }
        }

        private void HandleClient(TcpClient client)
        {
            NetworkStream stream = client.GetStream();
            byte[] buffer = new byte[1024];
            int bytesRead;

            while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) != 0)
            {
                string message = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                richTextBox1.Invoke(new Action(() => richTextBox1.AppendText(message + "\n")));

                foreach (TcpClient otherClient in clients)
                {
                    if (otherClient != client)
                    {
                        NetworkStream otherStream = otherClient.GetStream();
                        byte[] response = Encoding.ASCII.GetBytes(message);
                        otherStream.Write(response, 0, response.Length);
                    }
                }
            }

            clients.Remove(client);
            connectedClients.Remove(client.Client.RemoteEndPoint.ToString());
            UpdateConnectedClients();
        }

        private void UpdateConnectedClients()
        {
            StringBuilder sb = new StringBuilder();
            foreach (string client in connectedClients)
            {
                sb.AppendLine(client);
            }
            richTextBox3.Invoke(new Action(() => richTextBox3.Text = sb.ToString()));
        }
    }
}
