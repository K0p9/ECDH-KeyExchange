﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Lab03.Bai4.Client
{
    public partial class Client : Form
    {
        TcpClient client;
        NetworkStream stream;
        string clientName;
        public Client()
        {
            InitializeComponent();
        }

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            client = new TcpClient(richTextBoxIP.Text, 9999);
            stream = client.GetStream();

            richTextBox.AppendText("Connected to server.\n");
            richTextBox.AppendText("You've joined.\n");
            clientName = richTextBoxName.Text;

            Thread receiveThread = new Thread(ReceiveMessages);
            receiveThread.Start();
        }

        private void buttonSend_Click(object sender, EventArgs e)
        {
            string message = clientName + " " + DateTime.Now.ToString("(HH:mm:ss)") + ": " + richTextBoxMessage.Text;
            richTextBox.AppendText(message + "\n");
            richTextBoxMessage.Clear();

            byte[] data = Encoding.ASCII.GetBytes(message);
            stream.Write(data, 0, data.Length);
        }

        private void ReceiveMessages()
        {
            byte[] buffer = new byte[1024];
            int bytesRead;

            while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) != 0)
            {
                string message = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                richTextBox.Invoke(new Action(() => richTextBox.AppendText(message + "\n")));
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
